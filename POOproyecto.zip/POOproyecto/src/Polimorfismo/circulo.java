
package Polimorfismo;


public class circulo  extends figura{
    private double r; 
    
    public circulo(String color, double r){
        super(color);
        this.r = r;
    }
    
    @Override
    double area() {
        return Math.PI*r*r;
    }
    
    

}
