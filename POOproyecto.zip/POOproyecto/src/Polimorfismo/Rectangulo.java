
package Polimorfismo;

import Polimorfismo.Figura_1;

public class Rectangulo implements Figura_1{
    private final float lado;
    private final float altura;
    
    public Rectangulo(float lado , float altura){
        this.lado = lado;
        this.altura = altura;
    }
    
    @Override
    public float area(){
        return lado*altura;
    }
}
