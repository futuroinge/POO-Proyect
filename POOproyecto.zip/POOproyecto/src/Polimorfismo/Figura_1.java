
package Polimorfismo;

public interface Figura_1 {
    float PI = (float)(Math.PI);
    float area();
}
