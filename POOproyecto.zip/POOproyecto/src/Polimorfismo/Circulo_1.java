package Polimorfismo;

import Polimorfismo.Figura_1;

public class Circulo_1 implements Figura_1 {
    
    private final float diametro;
    
    public Circulo_1(float diametro){
    this.diametro = diametro;
    }
    
    @Override
    public float area(){
        return (PI * diametro *diametro/ 4f);
    }
    
}
