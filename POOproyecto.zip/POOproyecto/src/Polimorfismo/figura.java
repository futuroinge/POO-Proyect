package Polimorfismo;

public abstract class figura {
    private String color; 
    
    public figura(String color){
    this.color = color;
    }
    
    abstract double area();
    
    public String getColor(){
    return color;
    }
    

}
