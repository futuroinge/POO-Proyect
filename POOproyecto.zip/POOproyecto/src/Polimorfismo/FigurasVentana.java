/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Polimorfismo;

import java.awt.Color;
import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author karlo
 */
public class FigurasVentana extends javax.swing.JFrame {

    public String color;
    public int size;
    boolean btnSelected = false;
    ArrayList<Integer> Valor = new ArrayList<>();

    /**
     * Creates new form AbstraccionVentana
     */
    public FigurasVentana() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pane1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        btnAplicar = new javax.swing.JButton();
        theLabel = new javax.swing.JLabel();
        thePane = new javax.swing.JPanel();
        txtLabel1 = new javax.swing.JTextField();
        txtLabel2 = new javax.swing.JTextField();
        label2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        label1 = new javax.swing.JLabel();
        btnToggle = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pane1.setBackground(new java.awt.Color(208, 208, 208));

        jButton1.setText("Regresar");
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnAplicar.setText("APLICAR");
        btnAplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAplicarActionPerformed(evt);
            }
        });

        theLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/rectangulo.png"))); // NOI18N
        theLabel.setMaximumSize(new java.awt.Dimension(20000, 20000));
        theLabel.setMinimumSize(new java.awt.Dimension(1, 1));
        theLabel.setPreferredSize(null);

        txtLabel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLabel1ActionPerformed(evt);
            }
        });

        label2.setText("Color");

        jLabel1.setText("Negro = 0 | Rojo = 1  | Azul = 2");

        label1.setText("Largo: ");

        btnToggle.setText("Cuadrado");
        btnToggle.setMaximumSize(new java.awt.Dimension(140, 25));
        btnToggle.setPreferredSize(new java.awt.Dimension(140, 25));
        btnToggle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnToggleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout thePaneLayout = new javax.swing.GroupLayout(thePane);
        thePane.setLayout(thePaneLayout);
        thePaneLayout.setHorizontalGroup(
            thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(thePaneLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(thePaneLayout.createSequentialGroup()
                        .addGroup(thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label2)
                            .addComponent(label1))
                        .addGap(138, 138, 138)
                        .addGroup(thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                            .addComponent(txtLabel2))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, thePaneLayout.createSequentialGroup()
                .addContainerGap(114, Short.MAX_VALUE)
                .addComponent(btnToggle, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
        );
        thePaneLayout.setVerticalGroup(
            thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(thePaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnToggle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 189, Short.MAX_VALUE)
                .addGroup(thePaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label2))
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout pane1Layout = new javax.swing.GroupLayout(pane1);
        pane1.setLayout(pane1Layout);
        pane1Layout.setHorizontalGroup(
            pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pane1Layout.createSequentialGroup()
                .addGroup(pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addGroup(pane1Layout.createSequentialGroup()
                        .addGroup(pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pane1Layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(thePane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pane1Layout.createSequentialGroup()
                                .addGap(141, 141, 141)
                                .addComponent(btnAplicar)))
                        .addGap(30, 30, 30)
                        .addComponent(theLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        pane1Layout.setVerticalGroup(
            pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pane1Layout.createSequentialGroup()
                .addGroup(pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(theLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pane1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(63, 63, 63)
                        .addComponent(thePane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnAplicar)))
                .addContainerGap(105, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        MenuAbstracto ventana = new MenuAbstracto();
        ventana.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtLabel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLabel1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtLabel1ActionPerformed

    private void btnToggleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnToggleActionPerformed
        // TODO add your handling code here:

        if (btnToggle.isSelected()) {
            theLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/circulo.png")));
            btnToggle.setText("Circulo");
            label1.setText("Radio");
            btnSelected = true;
            Valor.add(1);
        } else if (!(btnToggle.isSelected())) {
            theLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/rectangulo.png")));
            btnToggle.setText("Cuadrado");
            label1.setText("Largo");
            btnSelected = false;
            Valor.add(1);
        }
    }//GEN-LAST:event_btnToggleActionPerformed

    private void btnAplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAplicarActionPerformed
        // TODO add your handling code here:

        int colorName = Integer.parseInt(txtLabel2.getText());
        ImageIcon icon = (ImageIcon) theLabel.getIcon();
        Image image = icon.getImage();

        int newSize = Integer.parseInt(txtLabel1.getText());
        Image scaledImage = image.getScaledInstance(newSize, newSize, Image.SCALE_DEFAULT);

        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        theLabel.setIcon(scaledIcon);

        Prueba interfaz = new Prueba(Float.parseFloat(txtLabel1.getText()));

        if (btnSelected) {
            JOptionPane.showMessageDialog(null,"Area del circulo "+interfaz.pruebaCirculo(Float.parseFloat(txtLabel1.getText())));
        } else {
            JOptionPane.showMessageDialog(null,"Area del rectangulo "+ interfaz.pruebaRectangulo(Float.parseFloat(txtLabel1.getText())));
        }

        if (colorName == 0) {
            thePane.setBackground(Color.BLACK);
        } else if (colorName == 1) {
            thePane.setBackground(Color.RED);
        } else if (colorName == 2) {
            thePane.setBackground(Color.BLUE);
        } else {
            thePane.setBackground(Color.gray);
        }


    }//GEN-LAST:event_btnAplicarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FigurasVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FigurasVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FigurasVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FigurasVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FigurasVentana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAplicar;
    private javax.swing.JToggleButton btnToggle;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JPanel pane1;
    private javax.swing.JLabel theLabel;
    private javax.swing.JPanel thePane;
    private javax.swing.JTextField txtLabel1;
    private javax.swing.JTextField txtLabel2;
    // End of variables declaration//GEN-END:variables
}
