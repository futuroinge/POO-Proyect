
package Polimorfismo;

import Polimorfismo.figura;

public class cuadrado extends figura {

    private double x;
    
    public cuadrado(double x,String color){
        super(color);
        this.x = x;
    }
    
    @Override
    double area() {
        return x*x;
    }
    
}
