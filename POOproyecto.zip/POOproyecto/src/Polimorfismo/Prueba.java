package Polimorfismo;

import Polimorfismo.Rectangulo;
import Polimorfismo.Circulo_1;
import Polimorfismo.Figura_1;
import java.util.ArrayList;

public class Prueba {

    public Prueba(float parseDouble) {
    }
    public float pruebaRectangulo(float input){
        Figura_1 rect1 = new Rectangulo(input, input);
        
        return rect1.area();
    }
    public float pruebaCirculo(float input){
        Figura_1 circ1 = new Circulo_1(input);
        Figura_1 rect1 = new Rectangulo(input, input);
        
        return circ1.area();
    }
    
    
    
}
